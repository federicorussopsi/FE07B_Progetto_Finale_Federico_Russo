import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <div class="container d-flex justify-content-center mt-5">
<div class="text-align-center">
  <img class="m-2" src="https://cdn-icons-png.flaticon.com/512/4306/4306889.png" width="60vw">
</div>
<div>
<h3>Benvenuto nel Sistema di <br>Fatturazione Epicode</h3>
</div>
    </div>
<br>
    <div class="container d-flex">

    <div class="card text-white bg-primary m-3" style="width: 28rem;">
  <div class="card-header"> <img src="../assets/img/login_black_24dp.svg"> <strong> Login</strong></div>
  <div class="card-body">
  <a class="btn btn-warning mb-3" [routerLink]="['/login']" routerLinkActive="active"><h5 class="card-title"> Accedi</h5></a>
    <p class="card-text">Inserisci le credenziali e accedi all'area personale</p>
  </div>
</div>

<div class="card text-white bg-success m-3" style="width: 28rem;">
<div class="card-header"> <img src="../assets/img/how_to_reg_black_24dp.svg"> <strong> Signup</strong></div>


  <div class="card-body">
  <a class="btn btn-warning mb-3" [routerLink]="['/signup']" routerLinkActive="active"><h5 class="card-title"> Registrati</h5></a>
    <p class="card-text">Inserisci i tuoi dati e crea un nuovo utente.</p>
  </div>
</div>
<div class="card text-white bg-danger m-3" style="width: 28rem;">
<div class="card-header"> <img src="../assets/img/account_circle_black_24dp.svg"><strong> Utenti</strong></div>
  <div class="card-body">
  <a class="btn btn-warning mb-3" [routerLink]="['/utenti']" routerLinkActive="active"><h5 class="card-title"> Elenco utenti</h5></a>
    <p class="card-text">Visualizza l'elenco degli utenti registrati</p>
  </div>

</div>
<div class="card text-white bg-secondary m-3" style="width: 28rem;">
  <div class="card-header"> <img src="../assets/img/people_alt_black_24dp.svg"> <strong> Elenco clienti</strong></div>
  <div class="card-body">
  <a class="btn btn-warning mb-3" [routerLink]="['/clienti']" routerLinkActive="active"><h5 class="card-title">Elenco clienti</h5></a>    <p class="card-text">Visualizza l'elenco dei clienti nel database, modifica, elimina e aggiungi un nuovo cliente.</p>
  </div>
</div>

<div class="card text-white bg-dark m-3" style="width: 28rem;">
  <div class="card-header"> <img src="../assets/img/article_black_24dp.svg"> <strong>Elenco fatture</strong></div>
  <div class="card-body">
  <a class="btn btn-warning mb-3" [routerLink]="['/fatture']" routerLinkActive="active"><h5 class="card-title">Fatture</h5></a>    <p class="card-text">Visualizza l'elenco delle fatture, modifica, elimina e aggiungi nuove fatture.</p>
  </div>
</div>
  </div>
  `,
  styles: [
  ]
})
export class HomePage implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
