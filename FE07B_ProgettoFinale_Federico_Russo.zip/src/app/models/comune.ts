import { Provincia } from "./provincia";

export class Comune {
  id: number;
  nome: string;
  provincia: Provincia = new Provincia();
}
