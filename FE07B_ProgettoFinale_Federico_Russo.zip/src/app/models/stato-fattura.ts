export interface StatoFattura {
  id: number;
  nome: string;
}
